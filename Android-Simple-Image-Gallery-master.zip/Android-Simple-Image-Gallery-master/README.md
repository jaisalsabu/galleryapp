# Android-Simple-Image-Gallery
A simple implementation of an image gallery app in android

MainActivity displays all folders with images and the number of images it contains <br />
<br />
![](https://cdn-images-1.medium.com/max/800/1*EDp_VGFCP9mFgWtYzon1yA.jpeg)   

Displays all images in a given folder, in this case "FastSave" <br />
<br />
![](https://cdn-images-1.medium.com/max/800/1*BPW6PN1oXPQ7z0sWDsNyLg.jpeg) 
<br />

Image slider/navigator <br />
![](https://cdn-images-1.medium.com/max/800/1*PHx4xIYzq4Jom9pNAx36yw.jpeg) 

### [Read the article on Medium](https://android.jlelse.eu/android-simple-image-gallery-30c0f00abe64?source=friends_link&sk=c203004612a1f0d402db9084feca42d4)












